import { Component, OnInit } from '@angular/core';
import { concat, empty, Observable, Observer, of, Subject, Subscription } from 'rxjs';
import { delay, filter, map, reduce, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit {
  obSub?: Subscription;
  subject?: Subject<number>;
  observable?: Observable<number>;

  ngOnInit(): void {
    // this.getPromise();

    // this.getPromise().then((data) => {
    //   console.log(`Promise Output - ${data}`);
    // }).catch((err) => {
    //   console.error(`Promise Error - ${err}`);
    // });

    // this.getObservable();

    // this.obSub = this.getObservable().subscribe((data) => {
    //   console.log(`Observable Output - ${data}`);
    // }, (err) => {
    //   console.error(`Observable Error - ${err}`);
    // });

    // setTimeout(() => {
    //   this.obSub?.unsubscribe();
    // }, 5000);

    // ------------------------------------- Observables are single-cast
    // this.getObservable().subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.getObservable().subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    //  ------------------------------------- Subjects are multi-cast
    // this.subject = this.getSubject();

    // this.subject.subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.subject.subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    //  ------------------------------------- Subjects as Observable
    // this.observable = this.getSubjectAsObservable();

    // this.observable.subscribe((data) => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.observable.subscribe((data) => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    //  ------------------------------------- Observable Operators & Methods
    // let numObservable = of(10, 20, 30, 40, 53, 60, 71, 85, 99);
    // // numObservable.subscribe(n => console.log(n));

    // let evenObservables = numObservable.pipe(
    //   filter(n => n % 2 == 0),
    //   map(n => n * 10),
    //   reduce((acc, n) => acc + n)
    // );
    // evenObservables.subscribe(n => console.log(n));

    // concat(
    //   of(10, 20, 30),
    //   of(40, 50, 60)
    // ).subscribe((message: any) => console.log(message));

    // concat(
    //   this.delayedMessage('Get Ready'),
    //   this.delayedMessage(5),
    //   this.delayedMessage(4),
    //   this.delayedMessage(3),
    //   this.delayedMessage(2),
    //   this.delayedMessage(1),
    //   this.delayedMessage('Go Now'),
    // ).subscribe((message: any) => console.log(message));
  }

  delayedMessage(message: any, delayTime = 1000) {
    return empty().pipe(startWith(message), delay(delayTime));
  }

  getSubjectAsObservable(): Observable<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s.asObservable();
  }

  // A Subject is a special type of Observable that allows values to be
  // multicasted to many Observers. Subjects are like EventEmitters.

  // Every Subject is an Observable and an Observer. You can subscribe to a
  // Subject, and you can call next to feed values as well as error and complete.
  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s;
  }

  getObservable(): Observable<number> {
    return Observable.create((ob: Observer<number>) => {
      setInterval(function () {
        // console.log("Observable - Set Interval Executed....");
        ob.next(Math.random());
      }, 4000);
    });
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      setInterval(function () {
        console.log("Promise - Set Interval Executed....");
        resolve(Math.random());
      }, 4000);
    });
  }
}
