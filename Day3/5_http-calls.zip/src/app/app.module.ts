import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { RootComponent } from './components/root/root.component';
import { UserComponent } from './components/user/user.component';

@NgModule({
  declarations: [RootComponent, UserComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule],
  bootstrap: [RootComponent]
})
export class AppModule { }
