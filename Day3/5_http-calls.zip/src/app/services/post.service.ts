import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Post } from "../models/post.interface";
import { catchError, delay, retry } from "rxjs/operators";
import { Observable, throwError } from "rxjs";

@Injectable()
export class PostService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = "https://jsonplaceholder.typicode.com/posts";
    }

    // getAllPosts(){
    //     return this.httpClient.get<Array<Post>>(this.url);
    // }

    getAllPosts() {
        return this.httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getPosts', []))
        );
    }

    insertPost(post: Post) {
        return this.httpClient.post<Post>(this.url, post).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('insertPost', post))
        );
    }

    deletePost(id: number) {
        var deleteURL = `${this.url}/${id}`;
        return this.httpClient.delete(deleteURL).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('deletePost'))
        );
    }

    private _handleError<T>(operation = "operation", result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            console.log(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, please try again later...');
        }
    }
}