import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { User } from 'src/app/models/user.interface';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'user',
  templateUrl: './user.component.html',
  providers: [UsersService]
})
export class UserComponent implements OnInit, OnDestroy {
  users?: Array<User>;
  flag: boolean;
  message?: string;
  get_sub?: Subscription;

  constructor(private usersService: UsersService) {
    this.flag = true;
  }

  ngOnInit(): void {
    this.get_sub = this.usersService.getAllUsers().subscribe(resData => {
      this.users = [...resData];
      this.flag = false;
    }, (err: string) => {
      this.message = err;
      this.flag = false;
    });
  }

  ngOnDestroy(): void {
		this.get_sub?.unsubscribe();
	}
}
