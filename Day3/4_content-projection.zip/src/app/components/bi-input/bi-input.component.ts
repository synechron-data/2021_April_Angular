import { Component, EventEmitter, HostBinding, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'bi-input',
  templateUrl: './bi-input.component.html',
  styleUrls: ['./bi-input.component.css']
})
export class BiInputComponent implements OnInit {
  @Input() icon?: string;
  @Output() value = new EventEmitter<string>();
  inputFocus = false;

  get classes() {
    const cssClasses: any = {
      bi: true
    };
    cssClasses["bi-" + this.icon] = true;
    return cssClasses;
  }

  constructor() { }

  ngOnInit(): void {
  }

  @HostBinding('class.focus')
  get focus() {
    return this.inputFocus;
  }
}
