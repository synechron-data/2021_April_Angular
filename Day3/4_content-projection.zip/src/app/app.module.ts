import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { GreetingsComponent } from './components/greetings/greetings.component';
import { BiInputComponent } from './components/bi-input/bi-input.component';
import { BiContentInputComponent } from './components/bi-content-input/bi-content-input.component';
import { InputRefDirective } from './directives/input-ref.directive';

@NgModule({
  declarations: [RootComponent, GreetingsComponent, BiInputComponent, BiContentInputComponent, InputRefDirective],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }
