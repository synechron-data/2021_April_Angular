import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidator } from 'src/app/utilities/customValidator';

@Component({
  selector: 'validation-form',
  templateUrl: './validation-form.component.html'
})
export class ValidationFormComponent {
  regForm: FormGroup;

  countries = [
    { 'id': "", 'name': 'Select Country' },
    { 'id': 1, 'name': 'India' },
    { 'id': 2, 'name': 'USA' },
    { 'id': 3, 'name': 'UK' }
  ];

  minAge = 18;
  maxAge = 60;

  constructor(private frmBuilder: FormBuilder) {
    this.regForm = this.frmBuilder.group({
      firstname: ["", Validators.required],
      lastname: ["", Validators.compose([
        Validators.required,
        Validators.maxLength(6),
        Validators.minLength(2)
      ])],
      gender: ["", Validators.required],
      age: ["", [
        Validators.required,
        // CustomValidator.ageRangeValidator
        CustomValidator.ageRangeValidator(this.minAge, this.maxAge)
      ]],
      address: this.frmBuilder.group({
        country: ["", Validators.required],
        city: ["", Validators.required],
        zip: ["", Validators.required]
      }),
      acceptTerms: [false, Validators.requiredTrue],
    });
  }

  get frm() { return this.regForm.controls; }
  get address() { return (<FormGroup>this.regForm.controls.address).controls; }

  logForm() {
    if (this.regForm.valid)
      console.log(this.regForm.value);
    else {
      this.regForm.markAllAsTouched();
      console.error("Invalid Form Data");
    }
  }

  reset() {
    this.regForm.reset();
  }
}
