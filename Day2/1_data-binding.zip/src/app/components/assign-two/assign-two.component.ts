import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'assign-two',
  templateUrl: './assign-two.component.html',
  styles: [
  ]
})
export class AssignTwoComponent implements OnInit {
  selected: string;

  constructor() { 
    this.selected = "";
  }

  ngOnInit(): void {
  }

}
