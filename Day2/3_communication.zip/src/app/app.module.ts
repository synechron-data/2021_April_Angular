import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { ListComponent } from './components/list/list.component';
import { HighlightDirective } from './directives/highlight.directive';
import { CounterComponent } from './components/counter/counter.component';

@NgModule({
  declarations: [RootComponent, ListComponent, HighlightDirective, CounterComponent],
  imports: [BrowserModule, FormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }