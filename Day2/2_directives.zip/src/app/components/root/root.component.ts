import { AfterViewInit, Component, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  myStyles: any;
  flag: boolean;
  name?: string;

  constructor() {
    this.flag = false;

    this.myStyles = {
      'background-color': 'green',
      'font-size': '20px',
      'color': 'white'
    };

    this.name = "Synechron";
  }
}
