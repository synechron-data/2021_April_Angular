import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  templateUrl: './comp-one.component.html'
})
export class CompOneComponent { }
