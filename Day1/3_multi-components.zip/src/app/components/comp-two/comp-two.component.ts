import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  templateUrl: './comp-two.component.html'
})
export class CompTwoComponent { }
