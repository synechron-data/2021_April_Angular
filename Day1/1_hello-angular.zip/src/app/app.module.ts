// ---------------------------------------------------- Default (Auto) Bootstraping
// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { HelloComponent } from './components/hello/hello.component';

// @NgModule({
//   declarations: [HelloComponent],
//   imports: [BrowserModule],
//   bootstrap: [HelloComponent]
// })
// export class AppModule { }

// ---------------------------------------------------- Manual (Custom) Bootstraping
import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HelloComponent } from './components/hello/hello.component';

@NgModule({
  declarations: [HelloComponent],
  imports: [BrowserModule],
  entryComponents: [HelloComponent]
})
export class AppModule implements DoBootstrap {
  ngDoBootstrap(appRef: ApplicationRef): void {
    const container = document.querySelector("#container");

    const helloTag = document.createElement('app-hello');
    helloTag.innerText = "Hello Tag Added Programatically";
    container?.appendChild(helloTag);

    appRef.bootstrap(HelloComponent);
  }
}