import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompOneComponent } from './components/comp-one/comp-one.component';
import { HelloComponent } from './components/hello/hello.component';

@NgModule({
  declarations: [CompOneComponent, HelloComponent],
  imports: [CommonModule],
  exports: [CompOneComponent]
})
export class MoneModule { }
