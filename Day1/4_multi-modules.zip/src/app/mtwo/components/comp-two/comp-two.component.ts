import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  templateUrl: './comp-two.component.html',
  styles: [
  ]
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
