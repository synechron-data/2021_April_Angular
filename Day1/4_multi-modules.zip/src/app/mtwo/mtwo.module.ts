import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompTwoComponent } from './components/comp-two/comp-two.component';
import { HelloComponent } from './components/hello/hello.component';

@NgModule({
  declarations: [CompTwoComponent, HelloComponent],
  imports: [CommonModule],
  exports: [CompTwoComponent]
})
export class MtwoModule { }
