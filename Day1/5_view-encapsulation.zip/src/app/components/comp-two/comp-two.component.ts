// import { Component, ViewEncapsulation } from '@angular/core';

// @Component({
//   selector: 'app-comp-two',
//   templateUrl: './comp-two.component.html',
//   encapsulation: ViewEncapsulation.ShadowDom
// })
// export class CompTwoComponent { }

// 3. Component Style
// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-comp-two',
//   templateUrl: './comp-two.component.html',
//   styles: [`
//     .card {
//           border-style: dashed;
//           border-width: 2px;
//           border-color: green;
//       }
//   `]
// })
// export class CompTwoComponent { }

// 4. External CSS
import { Component } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  templateUrl: './comp-two.component.html',
  styleUrls: ['./comp-two.component.css']
})
export class CompTwoComponent { }
