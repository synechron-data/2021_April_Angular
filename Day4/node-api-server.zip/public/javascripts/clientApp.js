$(document).ready(function () {
    $.post('/account/getToken', { username: "manish", password: "manish" }, function (data, status) {
        if (data.success)
            window.sessionStorage.setItem('tk', data.token);
        else
            console.error(data.message);
    });

    $("#btnLoad").click(function () {
        // alert("Button Clicked.....");
        $("#t_body").empty();

        $.ajax({
            url: 'api/users',
            type: 'GET',
            dataType: 'json',
            success: function (resData) {
                if (resData.data.length > 0) {
                    var tmpl = $.templates("#userRowTemplate");
                    var html = tmpl.render(resData.data);
                    $("#t_body").append(html);
                }
            },
            error: function (err) {
                console.error(err);
            },
            beforeSend: function (xhr) {
                xhr.setRequestHeader('x-access-token', window.sessionStorage.getItem('tk'));
            }
        });
    });
});