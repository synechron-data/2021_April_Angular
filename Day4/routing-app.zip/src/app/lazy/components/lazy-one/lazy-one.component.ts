import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lazy-one',
  template: `
    <h2 class="text-success">Lazy Component from Lazy Module Loaded...</h2> 
  `
})
export class LazyOneComponent implements OnInit {
  constructor() {
    console.log("Lazy Component - Ctor");
  }

  ngOnInit(): void {
    console.log("Lazy Component - Init");
  }
}
